# Coursera_Capstone
This notebook will be used for capstone project
import pandas as pd
import numpy as np
print('Hello Capstone Project Course!')
